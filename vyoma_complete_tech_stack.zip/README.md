# Vyoma One - Autonomous Delivery Platform

This repository contains the complete simulation, control, and AI software stack for Vyoma — a fully autonomous, small-scale delivery vehicle.

---

## 🚀 Getting Started

### 1. Clone the Repository
```bash
git clone https://github.com/<your-username>/vyoma.git
cd vyoma
```

### 2. Run the Auto-Installer
```bash
chmod +x vyoma_env_setup.sh
./vyoma_env_setup.sh
```

### 3. Build the Workspace
```bash
cd vyoma_ws
source /opt/ros/humble/setup.bash
colcon build
source install/setup.bash
ros2 launch launch bringup.launch.py
```

---

## 🧠 System Overview

- ROS 2 Humble
- YOLOv8 Object Detection
- PID Motion Controller
- LIDAR-based Obstacle Avoidance
- GPS + IMU Simulation
- RTAB-Map SLAM
- Behavior Trees
- Foxglove + Web Video Streaming

---

This repo is under active development by Jagadeesh and team. Welcome to the Vyoma movement.

