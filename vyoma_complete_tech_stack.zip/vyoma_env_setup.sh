#!/bin/bash

set -e

echo "🚀 Setting up Vyoma Developer Environment for ROS 2 Humble on Ubuntu 22.04"

# 1. Locale
sudo locale-gen en_US en_US.UTF-8
sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
export LANG=en_US.UTF-8

# 2. ROS 2 keys and repo
sudo apt update && sudo apt install -y curl gnupg2 lsb-release
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key | sudo tee /usr/share/keyrings/ros-archive-keyring.gpg > /dev/null
echo "deb [signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null

# 3. ROS 2 Humble
sudo apt update
sudo apt install -y ros-humble-desktop

# 4. ROS 2 Tools
sudo apt install -y python3-colcon-common-extensions python3-rosdep python3-rosinstall python3-vcstool build-essential
sudo rosdep init || true
rosdep update

# 5. ROS 2 Packages
sudo apt install -y ros-humble-rtabmap-ros \
                    ros-humble-web-video-server \
                    ros-humble-gazebo-ros \
                    ros-humble-gazebo-ros-pkgs \
                    ros-humble-nav2-bringup \
                    ros-humble-rviz2 \
                    ros-humble-tf2-tools \
                    ros-humble-rosbridge-server

# 6. Python Dependencies
sudo apt install -y python3-pip git
pip3 install --upgrade pip
pip3 install opencv-python torch torchvision torchaudio

# 7. Optional: VS Code
echo "✅ You may now install VS Code with: sudo snap install --classic code"
echo "   And install the ROS extension (ms-iot.vscode-ros) from the marketplace."

echo "🎉 Setup complete! Remember to source ROS:"
echo "    source /opt/ros/humble/setup.bash"
