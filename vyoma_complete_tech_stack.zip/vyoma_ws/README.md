# Vyoma One ROS 2 Stack

This is the starter template for Vyoma's autonomous vehicle stack.

---
## 📡 Connecting Vyoma to a Dashboard

### 🧭 Option 1: Foxglove Studio (No Code)
1. Launch with:
    ```
    ros2 launch launch/foxglove_streaming.launch.py
    ```
2. Open Foxglove Studio
3. Add WebSocket connection: `ws://localhost:9090`
4. Subscribe to:
    - `/camera/image_raw` (Video)
    - `/gps/fix` (GPS)
    - `/imu/data` (IMU)
    - `/odom` (Odometry)
    - `/scan` (LIDAR)
    - `/target_speed` (Speed Command)
    - `/human_detected` (Bool)

### 🖥️ Option 2: React Dashboard (Advanced)
Use `roslibjs` and `rosbridge_websocket` to stream and visualize real-time data in a custom frontend.
Refer: https://github.com/RobotWebTools/roslibjs

---

---

## 🧠 Vyoma One - Autonomous Delivery Vehicle (ROS 2 Tech Stack)

Vyoma is a fully autonomous, small-scale delivery vehicle platform. This repository contains the complete simulation and control software stack built on ROS 2 Humble. If you're new to self-driving systems, don't worry—this README walks you through everything.

---

### 🧱 Core Architecture Overview

1. **Camera + LiDAR**: Provides visual and spatial awareness of surroundings.
2. **Perception**: YOLOv8 detects objects; uses real camera input.
3. **Localization**: Simulated GPS + IMU and SLAM (RTAB-Map) provide map and positioning.
4. **Planning**: Route and motion planning handled with basic state machines.
5. **Control**: PID-based velocity control; stops on obstacles or humans.
6. **Simulation**: Gazebo for physics simulation; RViz for visualization.
7. **Dashboard**: Streams data to Foxglove or custom React UI via `rosbridge_websocket`.

---

### 🔧 Tech Stack Components

| Component        | Tool / Package               | Purpose                          |
|------------------|------------------------------|----------------------------------|
| OS               | Ubuntu 22.04 + ROS 2 Humble  | Core platform                    |
| Simulator        | Gazebo + RViz                | Testing + Visualization          |
| Sensors (Sim)    | LiDAR (Hokuyo), USB Camera   | Perception inputs                |
| Object Detection | YOLOv5 via PyTorch           | Detect humans, vehicles, etc     |
| SLAM             | RTAB-Map                     | Real-time 2D mapping             |
| Planner          | Custom nodes (multi-stop)    | Waypoint delivery simulation     |
| Controller       | PID + Behavior Tree          | Speed control + safety logic     |
| Dashboard        | Foxglove + web_video_server  | Real-time monitoring + streaming |
| Communication    | ROS Topics + rosbridge       | System-wide integration          |

---

### 📂 Key ROS 2 Packages in This Repo

- `yolov8_ros/`: Camera-based object detection (YOLO)
- `lane_detector/`: (Stub for future lane detection)
- `pid_controller/`: Controls linear velocity via `cmd_vel`
- `ekf_fusion_node/`: Placeholder for sensor fusion logic
- `gps_imu_simulator/`: Publishes fake GPS + IMU data
- `multi_stop_planner/`: Simulates multiple delivery stops
- `behavior_controller/`: Stops robot if human is detected
- `delivery_task/`: Controls simple go/stop behavior
- `robot_description/urdf`: Robot model for Gazebo
- `simulation/`: Contains Gazebo and CARLA support
- `launch/`: Launch files to run the system
- `utils/rviz_configs`: RViz dashboards for visual testing

---

### ✅ How to Run

```bash
cd vyoma_ws
source /opt/ros/humble/setup.bash
colcon build
source install/setup.bash
ros2 launch launch/bringup.launch.py
```

---

### 🔭 Visualization

- Run `foxglove_streaming.launch.py` to stream live to [Foxglove Studio](https://studio.foxglove.dev)
- Use RViz: `rviz2 -d src/utils/rviz_configs/vyoma_dashboard.rviz`

---

### 👨‍💻 How You Can Help

You can fine-tune:
- YOLO model on custom dataset
- PID gains for real hardware
- RTAB-Map tuning for mapping
- Add Kalman filter for GPS+IMU fusion
- Behavior tree with more delivery states

---

Welcome to Vyoma — the mission to build the Zoox of delivery vehicles starts here.

