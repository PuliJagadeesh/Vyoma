
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='rtabmap_ros',
            executable='rtabmap',
            name='rtabmap',
            parameters=[{
                'frame_id': 'base_link',
                'subscribe_rgbd': False,
                'subscribe_stereo': False,
                'subscribe_scan': True,
                'subscribe_scan_cloud': False,
                'subscribe_depth': False
            }],
            remappings=[
                ('scan', '/vyoma/hokuyo')
            ],
            output='screen'
        )
    ])
