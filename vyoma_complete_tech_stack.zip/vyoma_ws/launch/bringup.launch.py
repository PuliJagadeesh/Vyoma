
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(package='yolov8_ros', executable='yolov8_node', name='yolov8_node', output='screen'),
        Node(package='lane_detector', executable='lane_node', name='lane_detector', output='screen'),
        Node(package='ekf_fusion_node', executable='ekf_node', name='ekf_fusion_node', output='screen'),
        Node(package='global_planner', executable='global_planner_node', name='global_planner', output='screen'),
        Node(package='pid_controller', executable='pid_node', name='pid_controller', output='screen'),
        Node(package='mpc_controller', executable='mpc_node', name='mpc_controller', output='screen')
    ])

        ,
        Node(package='camera_stream', executable='camera_node', name='camera_stream', output='screen')

        ,
        Node(package='simple_planner', executable='simple_planner_node', name='simple_planner', output='screen')

        ,
        Node(package='delivery_task', executable='delivery_task_node', name='delivery_task', output='screen')

        ,
        Node(package='gps_imu_simulator', executable='gps_imu_simulator', name='gps_imu_simulator', output='screen'),
        Node(package='multi_stop_planner', executable='multi_stop_planner', name='multi_stop_planner', output='screen')

        ,
        Node(package='behavior_controller', executable='behavior_controller', name='behavior_controller', output='screen'),
        Node(package='rosbridge_server', executable='rosbridge_websocket', name='rosbridge', output='screen')
