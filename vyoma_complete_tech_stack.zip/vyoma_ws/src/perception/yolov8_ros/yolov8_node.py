
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Bool
from cv_bridge import CvBridge
import cv2
import torch

class YOLOv8Node(Node):
    def __init__(self):
        super().__init__('yolov8_node')
        self.bridge = CvBridge()
        self.sub = self.create_subscription(Image, '/camera/image_raw', self.callback, 10)
        self.alert_pub = self.create_publisher(Bool, '/human_detected', 10)
        self.model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)
        self.model.eval()
        self.get_logger().info("YOLO node with human detection enabled")

    def callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        results = self.model(frame)
        names = results.names
        labels = results.pred[0][:, -1].cpu().numpy() if len(results.pred[0]) else []
        human_detected = 0 in labels
        alert = Bool()
        alert.data = human_detected
        self.alert_pub.publish(alert)
        self.get_logger().info("Human detected!" if human_detected else "No humans in frame")

def main(args=None):
    rclpy.init(args=args)
    node = YOLOv8Node()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
