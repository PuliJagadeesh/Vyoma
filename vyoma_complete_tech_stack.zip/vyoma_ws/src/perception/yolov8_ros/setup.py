
from setuptools import setup

package_name = 'yolov8_ros'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='jagadeesh',
    maintainer_email='jagadeesh@example.com',
    description='Vyoma ROS 2 package',
    license='MIT',
    entry_points={
        'console_scripts': [
            'yolov8_node = yolov8_ros.yolov8_node:main'
        ],
    },
)
