
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image

class LaneDetector(Node):
    def __init__(self):
        super().__init__('lane_detector')
        self.subscription = self.create_subscription(Image, '/camera/image_raw', self.callback, 10)
        self.get_logger().info("Lane detector node initialized")

    def callback(self, msg):
        self.get_logger().info(f"Lane frame received: {msg.height}x{msg.width}")

def main(args=None):
    rclpy.init(args=args)
    node = LaneDetector()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
