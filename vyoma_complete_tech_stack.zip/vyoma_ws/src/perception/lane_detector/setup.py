
from setuptools import setup

package_name = 'lane_detector'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='jagadeesh',
    maintainer_email='jagadeesh@example.com',
    description='Vyoma ROS 2 package',
    license='MIT',
    entry_points={
        'console_scripts': [
            'lane_node = lane_detector.lane_node:main'
        ],
    },
)
