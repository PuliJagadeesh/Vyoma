
from setuptools import setup

package_name = 'camera_stream'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='jagadeesh',
    maintainer_email='jagadeesh@example.com',
    description='Vyoma ROS 2 package',
    license='MIT',
    entry_points={
        'console_scripts': [
            'camera_node = camera_stream.camera_node:main'
        ],
    },
)
