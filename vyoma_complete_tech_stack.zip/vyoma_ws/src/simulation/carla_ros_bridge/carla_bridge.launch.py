
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='carla_ros_bridge',
            executable='carla_ros_bridge',
            name='carla_ros_bridge',
            output='screen',
            parameters=[{'host': 'localhost', 'port': 2000}]
        )
    ])
