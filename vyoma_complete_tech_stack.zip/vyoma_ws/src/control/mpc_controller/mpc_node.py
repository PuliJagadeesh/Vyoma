
import rclpy
from rclpy.node import Node

class MPCController(Node):
    def __init__(self):
        super().__init__('mpc_controller')
        self.get_logger().info("MPC controller node initialized")

def main(args=None):
    rclpy.init(args=args)
    node = MPCController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
