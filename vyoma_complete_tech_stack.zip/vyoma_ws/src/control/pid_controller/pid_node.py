
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan

class PIDController(Node):
    def __init__(self):
        super().__init__('pid_controller')
        self.sub = self.create_subscription(Float64, '/target_speed', self.speed_callback, 10)
        self.scan_sub = self.create_subscription(LaserScan, '/vyoma/hokuyo', self.lidar_callback, 10)
        self.cmd_pub = self.create_publisher(Twist, '/vyoma/cmd_vel', 10)
        self.current_speed = 0.0
        self.target_speed = 0.5
        self.obstacle_nearby = False
        self.timer = self.create_timer(0.1, self.control_loop)
        self.get_logger().info("PID controller with obstacle avoidance started")

    def speed_callback(self, msg):
        self.target_speed = msg.data

    def lidar_callback(self, msg):
        if min(msg.ranges) < 0.7:
            self.obstacle_nearby = True
        else:
            self.obstacle_nearby = False

    def control_loop(self):
        twist = Twist()
        if self.obstacle_nearby:
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            self.get_logger().info("Obstacle detected! Stopping.")
        else:
            twist.linear.x = self.target_speed
            twist.angular.z = 0.0
        self.cmd_pub.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    node = PIDController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
