
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import NavSatFix, Imu
import random

class GPSSimulator(Node):
    def __init__(self):
        super().__init__('gps_imu_simulator')
        self.gps_pub = self.create_publisher(NavSatFix, '/gps/fix', 10)
        self.imu_pub = self.create_publisher(Imu, '/imu/data', 10)
        self.timer = self.create_timer(1.0, self.publish_data)
        self.get_logger().info("Simulated GPS/IMU publisher started")

    def publish_data(self):
        gps = NavSatFix()
        gps.latitude = 37.422 + random.uniform(-0.0001, 0.0001)
        gps.longitude = -122.084 + random.uniform(-0.0001, 0.0001)
        gps.altitude = 5.0
        self.gps_pub.publish(gps)

        imu = Imu()
        imu.linear_acceleration.x = 0.0
        imu.linear_acceleration.y = 0.0
        imu.linear_acceleration.z = 9.8
        imu.angular_velocity.z = random.uniform(-0.1, 0.1)
        self.imu_pub.publish(imu)
