
from setuptools import setup

package_name = 'ekf_fusion_node'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='jagadeesh',
    maintainer_email='jagadeesh@example.com',
    description='Vyoma ROS 2 package',
    license='MIT',
    entry_points={
        'console_scripts': [
            'ekf_node = ekf_fusion_node.ekf_node:main'
        ],
    },
)
