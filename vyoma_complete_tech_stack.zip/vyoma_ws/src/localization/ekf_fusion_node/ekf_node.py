
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu, NavSatFix

class EKFNode(Node):
    def __init__(self):
        super().__init__('ekf_fusion_node')
        self.create_subscription(Imu, '/imu/data', self.imu_callback, 10)
        self.create_subscription(NavSatFix, '/gps/fix', self.gps_callback, 10)
        self.get_logger().info("EKF fusion node initialized")

    def imu_callback(self, msg):
        self.get_logger().info("IMU data received")

    def gps_callback(self, msg):
        self.get_logger().info("GPS fix received")

def main(args=None):
    rclpy.init(args=args)
    node = EKFNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
