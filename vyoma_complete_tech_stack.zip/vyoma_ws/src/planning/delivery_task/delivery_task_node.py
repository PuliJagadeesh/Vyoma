
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64

class DeliveryTask(Node):
    def __init__(self):
        super().__init__('delivery_task')
        self.publisher = self.create_publisher(Float64, '/target_speed', 10)
        self.timer = self.create_timer(1.0, self.run_delivery)
        self.counter = 0
        self.get_logger().info("Starting delivery task")

    def run_delivery(self):
        msg = Float64()
        if self.counter < 10:
            msg.data = 0.5  # simulate driving
        else:
            msg.data = 0.0  # simulate arrival
        self.publisher.publish(msg)
        self.counter += 1

def main(args=None):
    rclpy.init(args=args)
    node = DeliveryTask()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
