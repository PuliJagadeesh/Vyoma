
from setuptools import setup

package_name = 'delivery_task'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='jagadeesh',
    maintainer_email='jagadeesh@example.com',
    description='Vyoma ROS 2 package',
    license='MIT',
    entry_points={
        'console_scripts': [
            'delivery_task_node = delivery_task.delivery_task_node:main'
        ],
    },
)
