
import rclpy
from rclpy.node import Node

class GlobalPlanner(Node):
    def __init__(self):
        super().__init__('global_planner')
        self.get_logger().info("Global planner node initialized")

def main(args=None):
    rclpy.init(args=args)
    node = GlobalPlanner()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
