
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
import time

class MultiStopPlanner(Node):
    def __init__(self):
        super().__init__('multi_stop_planner')
        self.pub = self.create_publisher(Float64, '/target_speed', 10)
        self.timer = self.create_timer(2.0, self.route_next)
        self.route = [0.5, 0.0, 0.5, 0.0, 0.5]
        self.idx = 0
        self.get_logger().info("Starting multi-stop delivery")

    def route_next(self):
        if self.idx < len(self.route):
            msg = Float64()
            msg.data = self.route[self.idx]
            self.pub.publish(msg)
            self.get_logger().info(f"Route step {self.idx + 1}/{len(self.route)}: Speed {msg.data}")
            self.idx += 1

def main(args=None):
    rclpy.init(args=args)
    node = MultiStopPlanner()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
