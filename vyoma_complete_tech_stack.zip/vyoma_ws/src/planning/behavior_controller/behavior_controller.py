
import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, Float64

class BehaviorController(Node):
    def __init__(self):
        super().__init__('behavior_controller')
        self.cmd_pub = self.create_publisher(Float64, '/target_speed', 10)
        self.human_sub = self.create_subscription(Bool, '/human_detected', self.human_cb, 10)
        self.safe_to_drive = True
        self.timer = self.create_timer(1.0, self.decision_loop)
        self.get_logger().info("Behavior tree controller active")

    def human_cb(self, msg):
        self.safe_to_drive = not msg.data

    def decision_loop(self):
        msg = Float64()
        msg.data = 0.5 if self.safe_to_drive else 0.0
        self.cmd_pub.publish(msg)
        self.get_logger().info(f"Driving: {msg.data > 0}")

def main(args=None):
    rclpy.init(args=args)
    node = BehaviorController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
