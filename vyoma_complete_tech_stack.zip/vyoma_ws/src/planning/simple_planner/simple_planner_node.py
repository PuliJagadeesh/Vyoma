
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
import math

class SimplePlanner(Node):
    def __init__(self):
        super().__init__('simple_planner')
        self.publisher = self.create_publisher(PoseStamped, '/planned_path', 10)
        self.timer = self.create_timer(1.0, self.publish_waypoints)
        self.index = 0
        self.get_logger().info("Simple planner node started")

    def publish_waypoints(self):
        pose = PoseStamped()
        pose.header.frame_id = "map"
        pose.pose.position.x = math.sin(self.index * 0.1) * 5.0
        pose.pose.position.y = math.cos(self.index * 0.1) * 5.0
        pose.pose.orientation.w = 1.0
        self.publisher.publish(pose)
        self.index += 1

def main(args=None):
    rclpy.init(args=args)
    node = SimplePlanner()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
